CREATE VIEW v_all_eval_client AS
  SELECT DISTINCT
    `tt`.`client_id` AS `client_id`,
    `tt`.`plan_id`   AS `plan_id`
  FROM `pes_gobal`.`v_all_eval_client_tmp` `tt`
  WHERE exists(SELECT `ca`.`obj_id`
               FROM `pes_gobal`.`t_client_archives` `ca`
               WHERE (`ca`.`obj_id` = `tt`.`client_id`));

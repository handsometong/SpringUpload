CREATE VIEW v_plan_within_client AS
  SELECT
    `tr`.`obj_id`           AS `resultId`,
    `tr`.`obj_id`           AS `reult_id`,
    `tr`.`project_id`       AS `project_id`,
    `ta`.`name`             AS `name`,
    `tr`.`diagnosis_result` AS `result`,
    `tr`.`is_confirm`       AS `confirm`,
    `so`.`name`             AS `orgname`
  FROM (((`pes_gobal`.`t_training_project_client` `t` LEFT JOIN `pes_gobal`.`t_training_result` `tr`
      ON (((`tr`.`project_id` = `t`.`project_id`) AND (`tr`.`client_id` = `t`.`client_id`)))) LEFT JOIN
    `pes_gobal`.`t_client_archives` `ta` ON ((`t`.`client_id` = `ta`.`obj_id`))) LEFT JOIN
    `pes_gobal`.`sys_organization` `so` ON ((`so`.`id` = `ta`.`org_id`)))
  WHERE (`tr`.`client_id` IS NOT NULL);

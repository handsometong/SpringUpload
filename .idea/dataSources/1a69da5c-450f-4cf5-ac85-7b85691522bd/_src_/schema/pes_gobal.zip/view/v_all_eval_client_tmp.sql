CREATE VIEW v_all_eval_client_tmp AS
  SELECT
    `pes_gobal`.`t_eval_plan_client`.`client_id` AS `client_id`,
    `pes_gobal`.`t_eval_plan_client`.`plan_id`   AS `plan_id`
  FROM `pes_gobal`.`t_eval_plan_client`
  UNION SELECT
          `pes_gobal`.`t_exam_result`.`client_id` AS `client_id`,
          `pes_gobal`.`t_exam_result`.`plan_id`   AS `plan_id`
        FROM `pes_gobal`.`t_exam_result`;

CREATE VIEW counselorinfo AS
  SELECT
    count(`t`.`creator_id`) AS `frequency`,
    sum(`t`.`spend_time`)   AS `totalTime`,
    `t`.`creator_id`        AS `userId`
  FROM `pes_gobal`.`t_intervention` `t`
  GROUP BY `t`.`creator_id`;

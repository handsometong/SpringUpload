CREATE VIEW v_practical_client AS
  SELECT
    `tr`.`obj_id`           AS `resultId`,
    `tr`.`project_id`       AS `project_id`,
    `ta`.`name`             AS `name`,
    `tr`.`diagnosis_result` AS `result`,
    `tr`.`is_confirm`       AS `confirm`,
    `so`.`name`             AS `orgname`
  FROM ((`pes_gobal`.`t_training_result` `tr` LEFT JOIN `pes_gobal`.`t_client_archives` `ta`
      ON ((`tr`.`client_id` = `ta`.`obj_id`))) LEFT JOIN `pes_gobal`.`sys_organization` `so`
      ON ((`so`.`id` = `ta`.`org_id`)));

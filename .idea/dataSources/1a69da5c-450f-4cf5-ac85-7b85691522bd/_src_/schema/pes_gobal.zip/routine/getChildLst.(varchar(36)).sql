CREATE FUNCTION getChildLst(rootId VARCHAR(36))
  RETURNS VARCHAR(1000)
  BEGIN
     DECLARE sTemp VARCHAR(1000);  
     DECLARE sTempChd VARCHAR(1000);  

    SET sTemp = '$';   
    SET sTempChd =rootId;   
   WHILE sTempChd is not null DO   
  SET sTemp = concat(sTemp,',',sTempChd);   
    SELECT group_concat(id) INTO sTempChd FROM sys_organization  where FIND_IN_SET(pid,sTempChd)>0;   
    END WHILE;   
  RETURN sTemp;   
END;
